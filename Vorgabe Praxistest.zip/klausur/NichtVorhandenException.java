package klausur;

/**
 * Diese Exception tritt auf, wenn ein gewünschtes Gefäß
 * nicht im Lager vorhanden ist
 * @author Doro
 *
 */
public class NichtVorhandenException extends Exception {

}
